package com.example.social.serviceImpl;

import com.example.social.service.OtpService;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Service
public class OtpServiceImpl implements OtpService {

	@Value("${twilio.phone_number}")
	private String twilioPhoneNumber;

	private final Random random = new Random();

	// OTP details ko store karne ke liye map: key -> mobile number, value -> OTP
	// details
	private final Map<String, OtpDetails> otpStorage = new HashMap<>();

	// Inner class OTP details ko hold karne ke liye
	private static class OtpDetails {
		private final String otp;
		private final long expiryTime; // milliseconds me expiry time

		public OtpDetails(String otp, long expiryTime) {
			this.otp = otp;
			this.expiryTime = expiryTime;
		}

		public String getOtp() {
			return otp;
		}

		public long getExpiryTime() {
			return expiryTime;
		}
	}

	// OTP generate aur Twilio ke through send karne ka method
	@Override
	public String generateOtp(String mobile) {

		try {
			if (otpStorage.containsKey(mobile)) {
				OtpDetails existingOtp = otpStorage.get(mobile);
				if (System.currentTimeMillis() < existingOtp.getExpiryTime()) {
					return "OTP already sent! Please wait until it expires.";
				}
			}

			String otp = String.format("%04d", random.nextInt(10000));
			long expiryTime = System.currentTimeMillis() + (1 * 60 * 1000); // OTP valid for 1 minutes

			// OTP aur expiry time store karo in-memory map me
			otpStorage.put(mobile, new OtpDetails(otp, expiryTime));

			try {
				// Twilio se SMS send karo
//				Message.creator(new PhoneNumber(mobile), new PhoneNumber(twilioPhoneNumber), "Your OTP is: " + otp)
//						.create();
			} catch (Exception ex) {
				ex.printStackTrace();
				return ex.getMessage();
			}
			System.out.println("otp : "+otp);
			return "OTP sent successfully";
		} catch (Exception ex) {
			ex.printStackTrace();
			return "Exception occur to generate OTP";
		}
	}

	// OTP verify karne ka method
	@Override
	public String verifyOtp(String mobile, String otp) {

		System.out.println("mobile-> " + mobile);
		System.out.println("otp-> " + otp);
		OtpDetails otpDetails = otpStorage.get(mobile);

		if (otpDetails == null) {
			return "No OTP found for this mobile number. Please request a new one.";
		}

		// Check karo ki OTP expire toh nahi ho chuka
		if (System.currentTimeMillis() > otpDetails.getExpiryTime()) {
			otpStorage.remove(mobile);
			return "OTP expired! Please request a new one.";
		}

		// OTP match check karo
		if (otpDetails.getOtp().equals(otp)) {
			otpStorage.remove(mobile); // OTP verify hone ke baad remove kar do
			return "OTP verified successfully";
		} else {
			return "Invalid OTP!";
		}
	}
}
