package com.example.social.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.social.Entity.UserDetails;
import com.example.social.repository.UserRepository;
import com.example.social.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public boolean isPhoneNumberExists(String phoneNumber) {
		return userRepository.existsByPhoneNumber(phoneNumber);
	}

//	@Override
//	public Optional<UserDetails> registerUser(UserDetails details) {
//	    if (isPhoneNumberExists(details.getPhoneNumber())) {
//	        return Optional.empty(); // Phone number already exists
//	    }
//	    try {
//	        UserDetails data = userRepository.save(details);
//	        return Optional.of(data);
//	    } catch (Exception e) {
//	        // Aap yahan par exception ko log kar sakte hain agar zaroori ho
//	        System.err.println("Error saving user: " + e.getMessage());
//	        throw e; // Exception ko wapas throw karein
//	    }
//	}

	@Override
	public Optional<UserDetails> registerUser(UserDetails details) {
		//UserDetails data = userRepository.save(details);
		return Optional.of(userRepository.save(details));

	}
}
