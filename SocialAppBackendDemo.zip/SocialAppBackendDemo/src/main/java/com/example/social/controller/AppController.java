package com.example.social.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.social.Entity.UserDetails;
import com.example.social.service.OtpService;
import com.example.social.service.UserService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/social/user")
public class AppController {

	@Autowired
	private UserService userService;

	@GetMapping("/checkPhoneNumber")
	public ResponseEntity<?> checkPhoneNumberExist(@RequestParam String phoneNumber) {

		System.out.println("phoneNumber " + phoneNumber);
		boolean phoneNumberExists = userService.isPhoneNumberExists(phoneNumber);

		System.out.println("phoneNumberExists - " + phoneNumberExists);

		return new ResponseEntity<>(phoneNumberExists, HttpStatus.OK);

	}

	@PostMapping("/register")
	public ResponseEntity<?> registerUser(@RequestBody UserDetails details) {

		Optional<UserDetails> user = userService.registerUser(details);

		if (user.isPresent()) {
			return ResponseEntity.status(HttpStatus.CREATED).body(user.get());
		} else {
			Map<String, String> errorResponse = new HashMap<>();
			errorResponse.put("message", "User registration failed. User might already exist.");
			return ResponseEntity.status(HttpStatus.CONFLICT).body(errorResponse);

	// return ResponseEntity.status(HttpStatus.CONFLICT).body("Phone number already exists.");
		}
	}

}
