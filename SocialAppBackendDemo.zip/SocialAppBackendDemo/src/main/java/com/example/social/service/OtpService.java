package com.example.social.service;

import org.springframework.stereotype.Service;

@Service
public interface OtpService {

	String generateOtp(String phoneNumber);

	String verifyOtp(String phoneNumber, String otp);
}
