package com.example.social.exception;

import java.util.HashMap;
import java.util.Map;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ResponseBody
    @ResponseStatus(HttpStatus.CONFLICT) // 409 Conflict for duplicate entry
    @ExceptionHandler(SQLIntegrityConstraintViolationException.class)
    public ResponseEntity<Object> handleDuplicatePhoneNumber(SQLIntegrityConstraintViolationException ex) {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("message", "Phone number already exists.");
        // Aap ch चाहें toh exception message ko log bhi kar sakte hain:
        // System.err.println("Duplicate phone number error: " + ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.CONFLICT);
    }

//    @ResponseBody
//    @ResponseStatus(HttpStatus.CONFLICT) // 409 Conflict for phone number already exists
//    @ExceptionHandler(PhoneNumberAlreadyExistsException.class)
//    public ResponseEntity<Object> handlePhoneNumberAlreadyExists(PhoneNumberAlreadyExistsException ex) {
//        Map<String, Object> errorResponse = new HashMap<>();
//        errorResponse.put("message", ex.getMessage());
//        return new ResponseEntity<>(errorResponse, HttpStatus.CONFLICT);
//    }

    // Aap yahan par aur bhi exceptions ke liye handlers add kar sakte hain
    @ResponseBody
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR) // 500 Internal Server Error for generic errors
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Object> handleGenericException(Exception ex) {
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("message", "An unexpected error occurred.");
        System.err.println("Generic error: " + ex.getMessage());
        return new ResponseEntity<>(errorResponse, HttpStatus.INTERNAL_SERVER_ERROR);
    }
}