package com.example.social.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.*;
import lombok.*;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Data
@Builder
@Table(name = "UserDetails")
public class UserDetails {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@Column(nullable = false)
	private String name;

	@Column(name = "phoneNumber", nullable = false, unique = true)
	private String phoneNumber;

	@Column(nullable = false)
	private String password;

	@Column(nullable = false)
	private String email;

	@Column(nullable = false)
	private String fcmtoken;

	@Column(nullable = false)
	private String location;

	@Column(nullable = false)
	private String age;

	@Column(nullable = false)
	private String gender;

	@Column(nullable = false)
	private boolean terms;

	@Column(name = "isBlocked", nullable = false)
	private boolean isBlocked = false;

	@Column(nullable = false)
	private double trust = 3.0;

	@Column(name = "createdDateTime", nullable = false)
	private LocalDateTime createdDateTime = LocalDateTime.now();

}
