package com.example.social.controller;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.social.service.OtpService;

@RestController
@RequestMapping("/social/otp")
@CrossOrigin(origins = "*")
public class OtpController {

	@Autowired
	private OtpService otpService;

	@GetMapping("/generateOtp")
	public ResponseEntity<?> generateOTP(@RequestParam String phoneNumber) {
		System.out.println("Number " + phoneNumber);
		String otpMessage = otpService.generateOtp(phoneNumber);
		System.out.println("otpMessage - " + otpMessage);
		if ("OTP sent successfully".equalsIgnoreCase(otpMessage)) {
			Map<String, Object> map = new HashMap<>();
			map.put("message", "OTP sent successfully");
			map.put("data", null);
			map.put("bolValue", true);
			map.put("status", HttpStatus.OK.value());
			map.put("timeStamp", LocalDateTime.now());
			return ResponseEntity.status(HttpStatus.OK).body(map);
		} else {
			Map<String, Object> map = new HashMap<>();
			map.put("message", "OTP sent failed");
			map.put("data", null);
			map.put("bolValue", false);
			map.put("status", HttpStatus.NOT_FOUND.value());
			map.put("timeStamp", LocalDateTime.now());
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body(map);
		}
	}

	// 🔹 Verify OTP
	@GetMapping("/verifyOTP")
	public ResponseEntity<?> verifyOtp(@RequestParam String phoneNumber, @RequestParam String otp) {
		String verifyOtp = otpService.verifyOtp(phoneNumber, otp);
		System.out.println("verifyOtp -> " + verifyOtp);
		if ("OTP verified successfully".equalsIgnoreCase(verifyOtp)) {
			return ResponseEntity.status(HttpStatus.OK).body(verifyOtp);
		} else {
			return ResponseEntity.status(HttpStatus.OK).body(verifyOtp);
		}

	}
}
