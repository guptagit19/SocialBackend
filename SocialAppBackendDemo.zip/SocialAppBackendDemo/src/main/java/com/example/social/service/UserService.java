package com.example.social.service;

import java.util.Optional;

import org.springframework.stereotype.Service;

import com.example.social.Entity.UserDetails;

@Service
public interface UserService {

	boolean isPhoneNumberExists(String phoneNumber);

	Optional<UserDetails> registerUser(UserDetails details);

}
